/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.edu.fatec.model;

import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author AD122176
 */
public class AlunoDAO {
 
    public void inserir(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
    
              
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Servlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Trab3", "trab3", "trab3");
            
            Statement st = con.createStatement();
            
            ResultSet rs = st.executeQuery("SELECT * FROM TRAB3.TBL_PROFESSORES");
         
         ArrayList<Aluno> lista = new ArrayList<Aluno>();

         while(rs.next()){
            String nome = rs.getString ( "Nome");
            String rg = rs.getString ("RG");
            String cpf = rs.getString("CPF");
            String ra = rs.getString ("RA");
            String endereco = rs.getString ("Endereco");
            String dtnasc = rs.getString ("DtNasc");
            String curso = rs.getString( "IdCurso" );
            int id = rs.getInt( "Id" );
            //estamos pegando do bando e jogando
            //para a memoria por isso vamos criar
            //objetos contendo os valores das tuplas
            //em banco

            Aluno a = new Aluno(id, 1 ,"");
            
            //passando valores
            
            lista.add(a);
            
            
            req.setAttribute("lista" , lista);
                       
         }
         //fechar o banco para economizar memoria
            rs.close();
            st.close();
         
            
        } catch (SQLException ex) {
            Logger.getLogger(Servlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    
         RequestDispatcher rd = req.getRequestDispatcher("AlunoCadastro.jsp");
         rd.forward(req, resp);
    }
}
            
    
